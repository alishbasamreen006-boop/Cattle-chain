import io
from datetime import date, timedelta
import pandas as pd
import plotly.express as px
import qrcode
import streamlit as st

import db, service, seed
from blockchain import Chain

st.set_page_config(page_title="CattleChain - Farm Management", page_icon="🐄", layout="wide")


@st.cache_resource
def get_chain():
    db.init()
    chain = Chain()
    service.resync(chain)   # re-anchor stored hashes if using the local test chain
    return chain

chain = get_chain()
db.init()

def qr_png(url):
    img = qrcode.make(url)
    buf = io.BytesIO(); img.save(buf, format="PNG")
    return buf.getvalue()

def verify_view(tag):
    animal = db.q("SELECT * FROM animals WHERE tag=?", (tag,))
    if not animal:
        st.error(f"No animal found with tag '{tag}'."); return
    a = animal[0]
    st.subheader(f"{a['name']} ({a['tag']})")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Species / Breed", f"{a['species']} / {a['breed']}")
    c2.metric("Age (months)", a["age_months"]); c3.metric("Weight (kg)", a["weight_kg"]); c4.metric("Current owner", a["owner"])
    results, missing, all_ok = service.verify(chain, tag)
    if all_ok:
        st.success("✅ HISTORY VERIFIED: every record matches its blockchain fingerprint.")
    else:
        st.error("❌ WARNING: some records do NOT match the blockchain. This history may have been altered.")
    if results:
        st.dataframe(pd.DataFrame(results).drop(columns=["id", "tx"]), width="stretch", hide_index=True)
    for m in missing:
        st.warning(f"A {m['event_type']} event exists on the blockchain but is missing/changed in the database.")
    with st.expander("Blockchain proof (technical)"):
        st.write("Mode:", "Public testnet" if chain.live else "Local test chain (demo)")
        st.write("Contract address:", chain.contract.address)
        st.dataframe(pd.DataFrame(chain.get_events(tag)), width="stretch", hide_index=True)

# ---------- Public verification page (opened by scanning the QR code) ----------
qp = st.query_params
if "tag" in qp:
    st.title("🐄 Verified Animal History")
    verify_view(qp["tag"])
    st.stop()

# ---------- Sidebar ----------
st.sidebar.title("🐄 CattleChain")
role = st.sidebar.selectbox("Logged in as", ["Farm Owner", "Veterinarian", "Buyer"])
pages = {"Farm Owner": ["Dashboard", "Animal Registry", "Health Records", "Milk & Expenses", "Sell / Transfer", "Verify & QR"],
         "Veterinarian": ["Health Records", "Verify & QR"], "Buyer": ["Verify & QR"]}[role]
page = st.sidebar.radio("Menu", pages)
st.sidebar.caption("Blockchain: " + ("Public testnet" if chain.live else "Local test chain (demo mode)"))
if st.sidebar.button("Load dummy demo data"):
    seed.seed(chain); st.sidebar.success("Dummy data loaded."); st.rerun()

animals = db.q("SELECT * FROM animals ORDER BY tag")
tags = [a["tag"] for a in animals]

# ---------- Dashboard ----------
if page == "Dashboard":
    st.title("Farm Dashboard")
    if not animals:
        st.info("No data yet. Click 'Load dummy demo data' in the sidebar, or register your first animal.")
    else:
        since7 = str(date.today() - timedelta(days=7)); month = str(date.today() - timedelta(days=30))
        milk7 = db.q("SELECT COALESCE(SUM(liters),0) s FROM milk WHERE day>=?", (since7,))[0]["s"]
        exp = db.q("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE day>=?", (month,))[0]["s"]
        inc = db.q("SELECT COALESCE(SUM(amount),0) s FROM income WHERE day>=?", (month,))[0]["s"]
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Active animals", len([a for a in animals if a["status"] == "Active"]))
        c2.metric("Milk, last 7 days (L)", f"{milk7:,.0f}")
        c3.metric("Expenses, 30 days (Rs)", f"{exp:,.0f}")
        c4.metric("Profit, 30 days (Rs)", f"{inc - exp:,.0f}", delta=f"{inc - exp:,.0f}")
        left, right = st.columns(2)
        milk = pd.DataFrame(db.q("SELECT day, SUM(liters) liters FROM milk GROUP BY day ORDER BY day"))
        if not milk.empty:
            left.plotly_chart(px.line(milk, x="day", y="liters", title="Daily milk production (L)"), width="stretch")
        ex = pd.DataFrame(db.q("SELECT category, SUM(amount) amount FROM expenses GROUP BY category"))
        if not ex.empty:
            right.plotly_chart(px.pie(ex, names="category", values="amount", title="Expenses by category"), width="stretch")
        st.subheader("Upcoming / overdue vaccinations")
        due = db.q("SELECT tag, rec_type, next_due FROM records WHERE next_due!='' ORDER BY next_due")
        latest = {}
        for d in due: latest[d["tag"]] = d   # latest next_due per animal
        rows = []
        for d in latest.values():
            days = (date.fromisoformat(d["next_due"]) - date.today()).days
            rows.append({"Animal": d["tag"], "Due date": d["next_due"], "Days left": days,
                         "Status": "OVERDUE" if days < 0 else ("Due soon" if days <= 14 else "OK")})
        if rows:
            st.dataframe(pd.DataFrame(rows).sort_values("Days left"), width="stretch", hide_index=True)

# ---------- Animal registry ----------
elif page == "Animal Registry":
    st.title("Animal Registry")
    if animals:
        st.dataframe(pd.DataFrame(animals), width="stretch", hide_index=True)
    st.subheader("Register a new animal")
    with st.form("reg", clear_on_submit=True):
        c1, c2, c3 = st.columns(3)
        tag = c1.text_input("Tag ID (e.g. MW-009)"); name = c2.text_input("Name")
        species = c3.selectbox("Species", ["Buffalo", "Cow", "Bull", "Calf"])
        breed = c1.text_input("Breed"); age = c2.number_input("Age (months)", 0, 300, 24)
        weight = c3.number_input("Weight (kg)", 0.0, 1500.0, 400.0)
        owner = st.text_input("Owner", "Farm Owner")
        if st.form_submit_button("Register and save proof on blockchain"):
            if not tag.strip():
                st.error("Tag ID is required.")
            elif tag in tags:
                st.error("This tag already exists.")
            else:
                db.run("INSERT INTO animals(tag,name,species,breed,age_months,weight_kg,owner,created) VALUES(?,?,?,?,?,?,?,?)",
                       (tag.strip(), name, species, breed, age, weight, owner, str(date.today())))
                _, h, tx = service.add_record(chain, tag.strip(), "REGISTRATION", date.today(),
                                              f"{species} {breed}, {age} months, {weight} kg", owner)
                st.success(f"Registered. Blockchain fingerprint: {h[:16]}...  Transaction: {tx[:18]}...")

# ---------- Health records ----------
elif page == "Health Records":
    st.title("Health and Vaccination Records")
    if not tags:
        st.info("Register an animal first.")
    else:
        with st.form("health", clear_on_submit=True):
            c1, c2 = st.columns(2)
            tag = c1.selectbox("Animal", tags)
            rtype = c2.selectbox("Record type", ["VACCINATION", "TREATMENT", "BREEDING", "CHECKUP"])
            rdate = c1.date_input("Date", date.today())
            nxt = c2.date_input("Next due date (optional)", value=None)
            details = st.text_area("Details (vaccine name, disease, medicine...)")
            by = st.text_input("Veterinarian / recorded by", "Dr. Demo Vet" if role == "Veterinarian" else "")
            if st.form_submit_button("Save and sign on blockchain"):
                if not details.strip() or not by.strip():
                    st.error("Details and vet name are required.")
                else:
                    _, h, tx = service.add_record(chain, tag, rtype, rdate, details, by, next_due=nxt or "")
                    st.success(f"Saved. Fingerprint {h[:16]}... recorded in transaction {tx[:18]}...")
        st.subheader("All records")
        rec = db.q("SELECT id, tag, rec_type, rec_date, details, next_due, by_user FROM records ORDER BY id DESC LIMIT 100")
        if rec: st.dataframe(pd.DataFrame(rec), width="stretch", hide_index=True)

# ---------- Milk & expenses ----------
elif page == "Milk & Expenses":
    st.title("Milk, Expenses and Profit per Animal")
    t1, t2, t3 = st.tabs(["Milk entry", "Expense / income entry", "Profit per animal"])
    with t1:
        with st.form("milk", clear_on_submit=True):
            tag = st.selectbox("Animal", tags) if tags else None
            day = st.date_input("Date", date.today()); liters = st.number_input("Liters", 0.0, 60.0, 10.0)
            if st.form_submit_button("Save milk") and tag:
                db.run("INSERT INTO milk(tag,day,liters) VALUES(?,?,?)", (tag, str(day), liters)); st.success("Saved.")
    with t2:
        with st.form("exp", clear_on_submit=True):
            kind = st.radio("Type", ["Expense", "Income"], horizontal=True)
            cat = st.selectbox("Category", ["Feed", "Medicine", "Labour", "Electricity/Water", "Transport", "Milk sale", "Animal sale", "Other"])
            amount = st.number_input("Amount (Rs)", 0.0, 10_000_000.0, 1000.0)
            tag = st.selectbox("For animal (optional)", [""] + tags); day = st.date_input("Date ", date.today())
            if st.form_submit_button("Save"):
                if kind == "Expense": db.run("INSERT INTO expenses(day,category,amount,tag,note) VALUES(?,?,?,?,?)", (str(day), cat, amount, tag or None, ""))
                else: db.run("INSERT INTO income(day,source,amount,tag) VALUES(?,?,?,?)", (str(day), cat, amount, tag or None))
                st.success("Saved.")
    with t3:
        price = st.number_input("Milk price (Rs per liter)", 0.0, 500.0, 120.0)
        days = st.slider("Period (days)", 7, 90, 30); since = str(date.today() - timedelta(days=days))
        n_active = max(len([a for a in animals if a["status"] == "Active"]), 1)
        shared = db.q("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE tag IS NULL AND day>=?", (since,))[0]["s"] / n_active
        rows = []
        for a in animals:
            liters = db.q("SELECT COALESCE(SUM(liters),0) s FROM milk WHERE tag=? AND day>=?", (a["tag"], since))[0]["s"]
            direct = db.q("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE tag=? AND day>=?", (a["tag"], since))[0]["s"]
            rev = liters * price
            rows.append({"Animal": a["tag"], "Name": a["name"], "Milk (L)": round(liters, 1), "Milk revenue (Rs)": round(rev),
                         "Direct cost (Rs)": round(direct), "Shared cost share (Rs)": round(shared), "Net (Rs)": round(rev - direct - shared)})
        if rows:
            df = pd.DataFrame(rows); st.dataframe(df, width="stretch", hide_index=True)
            st.plotly_chart(px.bar(df, x="Animal", y="Net (Rs)", title="Net profit per animal"), width="stretch")
            st.caption("Shared costs (feed, labour...) are split equally among active animals. This is a simple estimate.")

# ---------- Sell / transfer ----------
elif page == "Sell / Transfer":
    st.title("Sell or Transfer Ownership")
    active = [a for a in animals if a["status"] == "Active"]
    if not active:
        st.info("No active animals.")
    else:
        with st.form("sale", clear_on_submit=True):
            tag = st.selectbox("Animal", [a["tag"] for a in active]); buyer = st.text_input("Buyer name")
            price = st.number_input("Sale price (Rs)", 0.0, 100_000_000.0, 150000.0); sdate = st.date_input("Date", date.today())
            if st.form_submit_button("Complete sale and record on blockchain"):
                if not buyer.strip():
                    st.error("Buyer name is required.")
                else:
                    owner = db.q("SELECT owner FROM animals WHERE tag=?", (tag,))[0]["owner"]
                    service.add_record(chain, tag, "SALE", sdate, f"Sold by {owner} to {buyer} for Rs {price:,.0f}", owner)
                    db.run("UPDATE animals SET owner=? WHERE tag=?", (buyer, tag))
                    db.run("INSERT INTO income(day,source,amount,tag) VALUES(?,?,?,?)", (str(sdate), "Animal sale", price, tag))
                    st.success(f"Ownership of {tag} transferred to {buyer}. The buyer can now scan the QR code to see the verified history.")

# ---------- Verify & QR ----------
elif page == "Verify & QR":
    st.title("Verify History and Generate QR Code")
    if not tags:
        st.info("No animals yet.")
    else:
        tag = st.selectbox("Animal tag", tags)
        base = st.text_input("App address used inside the QR code", "http://localhost:8501",
                             help="On the demo day use your laptop's Wi-Fi IP (e.g. http://192.168.1.5:8501) so a phone can open it.")
        link = f"{base}/?tag={tag}"
        c1, c2 = st.columns([1, 3])
        c1.image(qr_png(link), caption=f"Scan to verify {tag}", width=220)
        c1.download_button("Download QR (PNG)", qr_png(link), file_name=f"{tag}_qr.png", mime="image/png")
        with c2: verify_view(tag)
        with st.expander("🧪 Demo: simulate someone tampering with the database"):
            st.caption("This edits a record directly in the database, bypassing the app. Then check verification again.")
            recs = db.q("SELECT id, rec_type, details FROM records WHERE tag=? ORDER BY id", (tag,))
            if recs:
                pick = st.selectbox("Record to alter", recs, format_func=lambda r: f"#{r['id']} {r['rec_type']}: {r['details'][:50]}")
                if st.button("Alter this record"):
                    db.run("UPDATE records SET details=? WHERE id=?", (pick["details"] + " [ALTERED]", pick["id"])); st.rerun()
